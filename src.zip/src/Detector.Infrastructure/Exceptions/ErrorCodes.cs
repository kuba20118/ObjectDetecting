namespace Detector.Infrastructure.Exceptions
{
    public class ErrorCodes
    {
        public static string ErrorCode => "error_code";
    }
}