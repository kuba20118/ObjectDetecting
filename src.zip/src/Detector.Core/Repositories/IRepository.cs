namespace Detector.Core.Repositories
{
    /*Marker repository*/
    public interface IRepository
    {     
    }
}