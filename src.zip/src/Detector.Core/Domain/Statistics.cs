using System;

namespace Detector.Core.Domain
{
    public class Statistics
    {
        public Guid Id { get; set; }

        protected Statistics()
        {      
        }
    }
}