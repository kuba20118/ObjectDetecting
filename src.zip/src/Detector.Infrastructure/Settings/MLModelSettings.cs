namespace Detector.Infrastructure.Settings
{
    public class MLModelSettings
    {
        public string OnnxModelFilePath { get; set; }
        public string MLNETModelFilePath { get; set; }
    }
}