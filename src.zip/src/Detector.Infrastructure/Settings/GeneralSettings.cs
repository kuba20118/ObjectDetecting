namespace Detector.Infrastructure.Settings
{
    public class GeneralSettings
    {
        public string Name { get; set; }
    }
}