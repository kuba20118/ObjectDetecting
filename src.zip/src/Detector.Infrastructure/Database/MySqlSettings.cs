namespace Detector.Infrastructure.Database
{
    public class MySqlSettings
    {
        public string ConnectionString { get; set; }
    }
}