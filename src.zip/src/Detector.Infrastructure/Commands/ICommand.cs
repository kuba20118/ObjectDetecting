namespace Detector.Infrastructure.Commands
{
    /*Marker Interface*/
    public interface ICommand
    {
    }
}