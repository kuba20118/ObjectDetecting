namespace Detector.Infrastructure.Database
{
    /*Marker Repository*/
    public interface ISqlRepository
    {    
    }
}