namespace Detector.Infrastructure.Database
{
    public interface IDataContext
    {
         
    }
}