namespace Detector.Infrastructure.Services
{
    /*Marker repository*/
    public interface IService
    {
    }
}