﻿
NOTE:

This folder is used to store the temporal image files being generated so they can be loaded by the TensorFlowScorer.
This is just a temporal workaround until ML.NET pipeline (TF transformer) supports loading images from in-memory streams. 
