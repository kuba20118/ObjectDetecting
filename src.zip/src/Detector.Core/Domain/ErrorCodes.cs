namespace Detector.Core.Domain
{
    public class ErrorCodes
    {
        public static string InvalidImage => "invalid_image";
    }
}